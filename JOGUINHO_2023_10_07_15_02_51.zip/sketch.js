var fonte;
var fonte2;
var tela = 0;
var img1;
var imgM;
var imgcarregamento;
var posiçãox;
var posiçãoy;
var velocidade;
var escalaLargura; // Escala em relação à largura
var escalaAltura;  // Escala em relação à altura
var isMobile = window.orientation > -1;
var back1 = [];
var plan1 = [];
var plan2 = [];
var plan3 = [];
var plan4 = [];
var plan5 = [];
var plan6 = [];
var plan7 = [];
var plan8 = [];
var robot = [];
var contador = 0
var contador1=0
var contador2=0
var contador3=0
var tempo = 0
var tempo1= 0
var tempo2=0
var robotT=0
var som 
var sombutton;
var posxrobot;
var velocidadeR;



function preload() {
  fonte = loadFont('fontes/SignikaNegative-Light.ttf');
  fonte2= loadFont('fontes/VT323-Regular.ttf')
  img = loadImage('imagens/background/fundo.png');
  imgM = loadImage('imagens/background/fundocelular.png')
  img1 = loadImage('imagens/rocket.png');
  img2 = loadImage('imagens/rocket2.png');
  img3= loadImage('imagens/estrelas.png');
  imgcarregamento= loadImage('imagens/telacarregamento.png')
  back1[0] = loadImage('imagens/background/back1.jpeg');
  back1[1] = loadImage('imagens/background/back2.jpeg');
  back1[2] = loadImage('imagens/background/back3.jpeg');
  back1[3] = loadImage('imagens/background/back4.jpeg');
  
  for (var i = 0; i < 25; i++) {
  var filename = 'imagens/planetas/349801745 (2)_' + (i + 1) + '.png';
  plan1[i] = loadImage(filename);
  }

  for (var j = 0; j < 25; j++) {
    var filename2 = 'imagens/planetas/planetas2/3600079622 (1)_' + (j + 1) + '.png';
    plan2[j] = loadImage(filename2);
  }
  
  for (var k = 0; k < 25; k++) {
    var filename3 = 'imagens/planetas/planetas3/3600079622 (2)_' + (k + 1) + '.png';
    plan3[k] = loadImage(filename3);
  }
  
  for (var l = 0; l < 25; l++) {
    var filename4 = 'imagens/planetas/planetas4/3879227120 (3)_'+ (l + 1) + '.png';
    plan4[l] = loadImage(filename4);
    }
  
  for (var m = 0; m < 25; m++) {
    var filename5 = 'imagens/planetas/planetas5/3879227120 (1)_'+ (m + 1) + '.png';
    plan5[m] = loadImage(filename5);
  }
  
    for (var n = 0; n < 25; n++) {
    var filename6 = 'imagens/planetas/planetas6/3879227120 (2)_'+ (n + 1) + '.png';
    plan6[n] = loadImage(filename6);
  }
  
  for (var o = 0; o < 25; o++) {
    var filename7 = 'imagens/planetas/planetas7/3879227120 (4)_'+ (o + 1) + '.png';
    plan7[o] = loadImage(filename7);
  }
  
  for (var p = 0; p < 25; p++) {
    var filename8 = 'imagens/planetas/planetas8/3879227120_'+ (p + 1) + '.png';
    plan8[p] = loadImage(filename8);
  }

   for (var z=0; z<33; z++){
    var filename9 = 'imagens/robot/Armature_walking_'+(z+1)+'.png';
    robot[z] = loadImage(filename9)
  }

  
  som = loadSound('music/music1.mp3');
  som.setVolume(0.5); // Define o volume para 50% para o primeiro som
  sombutton= loadSound('music/sombutton.mp3');
  
  
}

function startSong() {
  if (!som.isPlaying()) {
    som.play();
  } else {
    som.stop();
  }
}


function setup() {
  createCanvas(1800,1000);
  frameRate(60);
  textFont(fonte2, 24);
  posiçãox = -160;
  posiçãoy = height / 3;
  posiçãox1 = width;
  velocidade = 1;
  posxrobot=76;
  velocidadeR=2
  
  escalaLargura = width / 800;
  escalaAltura = height / 500;
  
   if (isMobile) {
    resizeCanvas(800, 400);

  }
  
  
  startSong();
  som.setLoop(true);
  
}

function draw() {
  
  if (tela === 0) {
    background(img);
  
    //foguete
    
    if(isMobile){
    if(posiçãox < width){
    
    image(img1, posiçãoX, 150, 400, 200);
  posiçãox= posiçãox+velocidade;
    
  } else {
    
        image(img2,posiçãox1, 150, 100, 100);
    posiçãox1=posiçãox1-velocidade;
    
  }
  }else{
    if(posiçãox < width){
    
    image(img1, posiçãox, posiçãoy, 100, 100);
  posiçãox= posiçãox+velocidade;
    
  } else {
    
        image(img2,posiçãox1, posiçãoy, 100, 100);
    posiçãox1=posiçãox1-velocidade;
    
  }}
    
    //if(posiçãox1<-400)
    
    //partes dos botões até o fim.
    
    if(isMobile){
      background(imgM);
    var larguraBotao = 300 * escalaLargura;
    var alturaBotao = 50 * escalaAltura;
    var botaoX = 250 * escalaLargura;
    var botaoY = 10 * escalaAltura;
    }else{
    var larguraBotao = 300 * escalaLargura;
    var alturaBotao = 50 * escalaAltura;
    var botaoX = 250 * escalaLargura;
    var botaoY = 40 * escalaAltura;
    }
    // Botão "JOGAR"
    if (
      mouseX >= botaoX &&
      mouseX <= botaoX + larguraBotao &&
      mouseY >= botaoY &&
      mouseY <= botaoY + alturaBotao
    ) {
      fill(0, 0, 200, 40);
      cursor(HAND);
    } else {
      fill(0, 0, 200, 0);
    }
    rect(botaoX, botaoY, larguraBotao, alturaBotao, 30 * escalaLargura);
    textAlign(CENTER, CENTER);
    fill(255);
    textSize(24 * escalaLargura);
    text("JOGAR", botaoX + larguraBotao / 2, botaoY + alturaBotao / 2);

    // Botão "CONFIGURAÇÕES"
     if(isMobile){ 
    var botaoConfigX = 250 * escalaLargura;
    var botaoConfigY = 80 * escalaAltura;
}else{
    var botaoConfigX = 250 * escalaLargura;
    var botaoConfigY = 110 * escalaAltura;
}
    if (
      mouseX >= botaoConfigX &&
      mouseX <= botaoConfigX + larguraBotao &&
      mouseY >= botaoConfigY &&
      mouseY <= botaoConfigY + alturaBotao
    ) {
      fill(0, 0, 200, 40);
      cursor(HAND);
    } else {
      fill(0, 0, 200, 0);
    }
    rect(botaoConfigX, botaoConfigY, larguraBotao, alturaBotao, 30 * escalaLargura);
    textAlign(CENTER, CENTER);
    fill(255);
    textSize(24 * escalaLargura);
    text("CONFIGURAÇÕES", botaoConfigX + larguraBotao / 2, botaoConfigY + alturaBotao / 2);

    // Botão "TELA CHEIA"
     if(isMobile){
    var botaoFullScreenX = 250 * escalaLargura;
    var botaoFullScreenY = 150 * escalaAltura;
     }else{ 
    var botaoFullScreenX = 250 * escalaLargura;
    var botaoFullScreenY = 180 * escalaAltura;
     }
    if (
      mouseX >= botaoFullScreenX &&
      mouseX <= botaoFullScreenX + larguraBotao &&
      mouseY >= botaoFullScreenY &&
      mouseY <= botaoFullScreenY + alturaBotao
    ) {
      fill(0, 0, 200, 40);
      cursor(HAND);
    } else {
      fill(0, 0, 200, 0);
    }
    rect(botaoFullScreenX, botaoFullScreenY, larguraBotao, alturaBotao, 30 * escalaLargura);
    textAlign(CENTER, CENTER);
    fill(255);
    textSize(24 * escalaLargura);
    text("TELA CHEIA", botaoFullScreenX + larguraBotao / 2, botaoFullScreenY + alturaBotao / 2);


  } 
  
  //tela1 botão jogar
  
  else if (tela === 1) {
    //imagens de background
    
    tempo++
    background(0); 
    image(back1[contador%4], 0,0);
    if(tempo>50){
      contador++
      tempo=0
    }
    image(back1[contador%4], 300,0);
    image(back1[contador%4], 500,0);
    image(back1[contador%4], 700,0);
    image(back1[contador%4], 900,0);
    image(back1[contador%4], 1100,0);
    image(back1[contador%4], 1300,0);
    image(back1[contador%4], 1500,0);
    image(back1[contador%4], 0,200);
    image(back1[contador%4], 300, 200);
    image(back1[contador%4], 500, 200);
    image(back1[contador%4], 700, 200);
    image(back1[contador%4], 900, 200);
    image(back1[contador%4], 1100, 200);
    image(back1[contador%4], 1300, 200);
    image(back1[contador%4], 1500, 200);
    image(back1[contador%4], 0,400);
    image(back1[contador % 4], 300, 400);
    image(back1[contador % 4], 500, 400);
    image(back1[contador % 4], 700, 400);
    image(back1[contador % 4], 900, 400);
    image(back1[contador % 4], 1100, 400);
    image(back1[contador % 4], 1300, 400);
    image(back1[contador % 4], 1500, 400);
    image(back1[contador%4], 0,600);
    image(back1[contador % 4], 300, 600);
    image(back1[contador % 4], 500, 600);
    image(back1[contador % 4], 700, 600);
    image(back1[contador % 4], 900, 600);
    image(back1[contador % 4], 1100, 600);
    image(back1[contador % 4], 1300, 600);
    image(back1[contador % 4], 1500, 600);
    image(back1[contador%4], 0,800);
    image(back1[contador % 4], 300, 800);
    image(back1[contador % 4], 500, 800);
    image(back1[contador % 4], 700, 800);
    image(back1[contador % 4], 900, 800);
    image(back1[contador % 4], 1100, 800);
    image(back1[contador % 4], 1300, 800);
    image(back1[contador % 4], 1500, 800);



    //imagens dos planetas
    tempo1++
    image(plan1[contador1%25],100, 180, 320, 320); 
    if(tempo1>8){
      contador1++
      tempo1=0
    }
    
    image(plan8[contador1%25], 520, 180, 320, 320);
    image(plan3[contador1%25], 940, 180, 320, 320);
    image(plan4[contador1%25], 1200, 40, 620, 620);
    image(plan5[contador1%25],100, 600, 320, 320);
    image(plan7[contador1%25],360, 460, 600, 600);
    image(plan6[contador1%25],940, 600, 320, 320);
    image(plan2[contador1%25],1360, 600, 320, 320);
    
    if(mouseX>=100 && mouseX<=420 && mouseY>=180 && mouseY<=500){
      image(plan1[contador1%25],80, 160, 370, 370);
      
    }
    
    if(mouseX>=520 && mouseX<=840 && mouseY>=180 && mouseY<=500){
      image(plan8[contador1%25], 500, 160, 370, 370);
    }
    
    if(mouseX>=940 && mouseX<=1260 && mouseY>=180 && mouseY<=500){
      image(plan3[contador1%25],920, 160, 370, 370);
    }
    
    if(mouseX>=1402 && mouseX<=1616 && mouseY>=245 && mouseY<=456){
      image(plan4[contador1%25],1190, 35, 640, 640);
    }
    
    if(mouseX>=100 && mouseX<=420 && mouseY>=600 && mouseY<=920){
      image(plan5[contador1%25],80, 580, 370, 370);
    }
    
    if(mouseX>=538 && mouseX<=781 && mouseY>=623 && mouseY<=866){
      image(plan7[contador1%25],350, 435, 640, 640);
    }
    
    if(mouseX>=940 && mouseX<=1260 && mouseY>=600 && mouseY<=920){
      image(plan6[contador1%25],920, 580, 370, 370);
    }
    
    if(mouseX>=1360 && mouseX<=1580 && mouseY>=600 && mouseY<=920){
      image(plan2[contador1%25],1340, 580, 370, 370);
    }
    
    
    fill(200,0, 0);
    dirIcon("LFT", 20, 30); 
    fill('#FFEB3B');
    textFont(fonte2, 100);
    text('ESCOLHA O MUNDO', width/2, 60)
    textFont(fonte2, 30);
    text('TERRA', 255, 550);
    text('MARTE', 685, 550);
    text('JÚPITER', 1098, 550);
    text('SATURNO', 1528, 550);
    text('NETUNO', 255, 970);
    text('BURACO NEGRO', 685, 970);
    text('LUA', 1098, 970);
    text('URANO', 1528, 970);
    
    


    
    // Voltar pra tela menu
    if (keyIsPressed && key === 'm'){
    
      tela = 0; 
    }
  }
  
  //tela2 botão configurações
  
  else if (tela === 2) {
    
    tempo2++
    background(0); 
    image(back1[contador2%4], 0,0);
    if(tempo2>50){
      contador2++
      tempo2=0
    }
    image(back1[contador2%4], 300,0);
    image(back1[contador2%4], 500,0);
    image(back1[contador2%4], 500,200);
    image(back1[contador2%4], 300,200);
    image(back1[contador2%4], 0,200);
    image(back1[contador2%4], 0,400);
    image(back1[contador2%4], 0,200);
    image(back1[contador2%4], 0,600);
    image(back1[contador2%4], 0,800);
    image(back1[contador2%4], 800,0);
    image(back1[contador2%4], 1100,0);
    image(back1[contador2%4], 1300,0);
    image(back1[contador2%4], 700,200);
    image(back1[contador2%4], 900,200);
    image(back1[contador2%4], 1100,200);
    image(back1[contador2%4], 1300,200);
    image(back1[contador2%4], 700,600);
    image(back1[contador2%4], 900,600);
    image(back1[contador2%4], 1100,600);
    image(back1[contador2%4], 1300,600);
    image(back1[contador2%4], 700,800);
    image(back1[contador2%4], 900,800);
    image(back1[contador2%4], 1100,800);
    image(back1[contador2%4], 1300,800);
     image(back1[contador2%4], 700,200);
    image(back1[contador2%4], 900,200);
    image(back1[contador2%4], 1100,200);
    image(back1[contador2%4], 1300,200);
    image(back1[contador2%4], 300,800);
    image(back1[contador2%4], 300,400);
    image(back1[contador2%4], 500,400);
    image(back1[contador2%4], 700,400);
    image(back1[contador2%4], 900,400);
    image(back1[contador2%4], 1100,400);
    image(back1[contador2%4], 1300,400);
    image(back1[contador2%4], 500,800);
    image(back1[contador2%4], 300,600);
    image(back1[contador2%4], 400,600);
    image(back1[contador2%4], 1600,0);
    image(back1[contador2%4], 1600,200);
    image(back1[contador2%4], 1600,400);
     image(back1[contador2%4], 1600,600);
    image(back1[contador2%4], 1600,800);
    image(back1[contador2%4], 1600,1000);
    
    
    fill(200,0, 0);
    dirIcon("LFT", 20, 30); 
    fill(0, 0, 200, 40)
    rect(400, 110, 1000, 700, 50)
    fill('#F7F1B8');
    textFont(fonte2, 60);
    text('SOM', 900, 140);
    textFont(fonte2, 30);
    text('Música de Fundo', 550, 300)
    text('Efeitos Sonoros', 550, 550)
    

  }else if (tela === 3) {
    background(imgcarregamento)
    text(mouseX+' '+mouseY, 200, 200)
    //76 816
   
    
   robotT++
    image(robot[contador3%33],posxrobot, 600, 300, 300); 
    if(robotT>1){
      contador3++
      robotT=0
    }
    posxrobot=posxrobot+velocidadeR
    
    if(posxrobot>2000){
      posxrobot=-300
    }
    
    fill(200,0, 0);
    dirIcon("LFT", 20, 30);
}
  
    
  
}


function mouseClicked(){
  
  escalaLargura = width / 800;
  escalaAltura = height / 500;
  
  //var Botão jogar
  
   if(isMobile){
    var larguraBotao = 300 * escalaLargura;
    var alturaBotao = 50 * escalaAltura;
    var botaoX = 250 * escalaLargura;
    var botaoY = 10 * escalaAltura;
    }else{
    var larguraBotao = 300 * escalaLargura;
    var alturaBotao = 50 * escalaAltura;
    var botaoX = 250 * escalaLargura;
    var botaoY = 40 * escalaAltura;
    }
  
  // var Botão configurações
  
  if(isMobile){ 
    var botaoConfigX = 250 * escalaLargura;
    var botaoConfigY = 80 * escalaAltura;
    }else{
    var botaoConfigX = 250 * escalaLargura;
    var botaoConfigY = 110 * escalaAltura;
}
  
  //var Botão tela cheia
  
  if(isMobile){
    var botaoFullScreenX = 250 * escalaLargura;
    var botaoFullScreenY = 150 * escalaAltura;
     }else{ 
    var botaoFullScreenX = 250 * escalaLargura;
    var botaoFullScreenY = 180 * escalaAltura;
     }
    
  //inicio das funções clickes
  
  if(mouseX >= botaoX &&
      mouseX <= botaoX + larguraBotao &&
      mouseY >= botaoY &&
      mouseY <= botaoY + alturaBotao && tela==0){
    tela=1
    sombutton.play();
  }
  
  if (
      mouseX >= botaoConfigX &&
      mouseX <= botaoConfigX + larguraBotao &&
      mouseY >= botaoConfigY &&
      mouseY <= botaoConfigY + alturaBotao && tela==0
    ) {
      tela=2
      sombutton.play();
    }
     
  
      if (
      mouseX >= botaoFullScreenX &&
      mouseX <= botaoFullScreenX + larguraBotao &&
      mouseY >= botaoFullScreenY &&
      mouseY <= botaoFullScreenY + alturaBotao && tela==0
    ) {
        var fs = fullscreen();
        fullscreen(!fs);
        sombutton.play();
      } 
  
    //botão de voltar de cada tela
  if(mouseX>=24 && mouseX<=57 && mouseY>=39 && mouseY<=61 && tela==1){
    tela=0
    sombutton.play();
  }
  
  if(mouseX>=24 && mouseX<=57 && mouseY>=39 && mouseY<=61 && tela==2){
    tela=0
    sombutton.play();
  }
  if(mouseX>=100 && mouseX<=420 && mouseY>=180 && mouseY<=500 && tela==1){
    tela=3
    sombutton.play();
    
  }
  
  if(mouseX>=24 && mouseX<=57 && mouseY>=39 && mouseY<=61 && tela==3){
    tela=1
    sombutton.play();
  }
}
















































//alguns icons se precisar
/*
gearIcon(50, 50, "#FF0000");
xicon(100, 50, "#00FF00"); 
menuIcon(150, 50, "#0000FF"); 
pauseIcon(200, 50, "#FF00FF"); 
fsIcon(250, 50, "#FFFF00"); 
startIcon(300, 50, "#FFA500"); 
celularIcon(350, 50, "#808080"); 
muteIcon(400, 50, "#008080"); 
soundIcon(450, 50, "#800080"); 
perfilIcon(500, 50, "#808000"); 
resetIcon(550, 50, "#800000"); 
dirIcon("LFT", 600, 50, "#008000"); 
dirIcon("RGT", 650, 50, "#008000"); 
dirIcon("UP", 700, 50, "#008000"); 
dirIcon("DWN", 750, 50, "#008000");
*/

